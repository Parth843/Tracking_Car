#!/bin/bash
./build/vehicle_detection_haarcascades cars.xml dataset/video2.avi
